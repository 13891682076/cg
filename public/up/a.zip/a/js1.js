var color = 0,
  span = 10,
  colorString = "",
  bgString = "";

var list = document.querySelectorAll(".rainbowList a");

for (var i = 0; i < list.length; i++) {

  color += span;

  colorString = "hsl(" + color + ",100%,50%)",
    bgString = "hsla(" + color + ",100%,50%,0.2)";

  list[i].style.color = colorString;
  list[i].style.backgroundColor = bgString;
  list[i].style.borderColor=colorString;
}